package com.primeflix.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private data class Film(val title: String, val description: String, val url: String)

private val demoFilms = listOf(
    Film(
        "Big Buck Bunny",
        "Demo streaming video dari Blender Foundation.",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    ),
    Film(
        "Elephant Dream",
        "Demo film animasi dari Blender Foundation.",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeFlixApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrimeFlixApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var selectedUrl by remember { mutableStateOf<String?>(null) }
    var selectedTitle by remember { mutableStateOf("") }
    var localVideo by remember { mutableStateOf(false) }
    val favorites = remember { mutableStateListOf<String>() }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            selectedUrl = uri.toString()
            selectedTitle = "Video dari perangkat"
            localVideo = true
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF35A7E8),
            background = Color(0xFF080D18),
            surface = Color(0xFF111A2B)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF080D18),
            topBar = {
                TopAppBar(
                    title = {
                        Text("PRIME", color = Color.White, fontWeight = FontWeight.Black) 
                        // Brand is an independent demo app, not affiliated with Prime Video.
                    },
                    actions = {
                        IconButton(onClick = { picker.launch(arrayOf("video/*")) }) {
                            Icon(Icons.Default.FolderOpen, "Pilih video", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D18))
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
            ) {
                Text("FLIX", color = Color(0xFF35A7E8), fontWeight = FontWeight.Black, fontSize = 28.sp)
                Text("Film pilihan dan video milikmu", color = Color.LightGray, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Cari film...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(14.dp))

                if (selectedUrl != null) {
                    Text(selectedTitle, color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    VideoPlayer(url = selectedUrl!!, isLocal = localVideo)
                    TextButton(onClick = { selectedUrl = null }) { Text("Tutup pemutar") }
                    Spacer(Modifier.height(8.dp))
                }

                Text("Koleksi streaming demo", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Contoh video legal untuk uji coba. Ketersediaan stream memerlukan internet.",
                    color = Color.Gray, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))

                val filtered = demoFilms.filter { it.title.contains(query, ignoreCase = true) }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered) { film ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF142238)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(54.dp).background(Color(0xFF203C5C), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(film.title, color = Color.White, fontWeight = FontWeight.Bold)
                                    Text(film.description, color = Color.LightGray, fontSize = 12.sp)
                                    TextButton(
                                        contentPadding = PaddingValues(0.dp),
                                        onClick = {
                                            selectedUrl = film.url
                                            selectedTitle = film.title
                                            localVideo = false
                                        }
                                    ) { Text("Putar sekarang") }
                                }
                                IconButton(onClick = {
                                    if (favorites.contains(film.title)) favorites.remove(film.title)
                                    else favorites.add(film.title)
                                }) {
                                    Icon(
                                        if (favorites.contains(film.title)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorit",
                                        tint = Color(0xFF35A7E8)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Favorit: ${if (favorites.isEmpty()) "Belum ada" else favorites.joinToString()}", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { picker.launch(arrayOf("video/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1479B8))
                ) {
                    Icon(Icons.Default.FolderOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Pilih video dari HP")
                }
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@Composable
private fun VideoPlayer(url: String, isLocal: Boolean) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(220.dp)
    )
}
