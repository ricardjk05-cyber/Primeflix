# PrimeFlix — proyek awal Android

Ini adalah **proyek sumber Android**, belum berupa file APK siap instal.

## Fitur pada versi awal
- Katalog streaming demo (Big Buck Bunny dan Elephant Dream).
- Pencarian judul.
- Pemutar video menggunakan Android Media3.
- Memilih dan memutar video dari penyimpanan perangkat.
- Daftar favorit selama aplikasi sedang terbuka.

Video demo disediakan untuk pengujian pemutar. Aplikasi ini tidak membuka katalog Prime Video, tidak memuat film berhak cipta tanpa izin, dan tidak berafiliasi dengan Amazon/Prime Video.

## Cara membangun APK
1. Instal Android Studio versi stabil di komputer.
2. Ekstrak folder `PrimeFlix-Android`.
3. Buka folder tersebut melalui Android Studio.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh dependensi.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Setelah selesai, pilih **locate** pada notifikasi untuk menemukan `app-debug.apk`.
7. Pindahkan APK ke HP Android dan instal. Android mungkin meminta izin instalasi dari sumber tersebut.

## Catatan
- Butuh internet untuk memutar video streaming demo.
- Pemutaran file lokal menggunakan pemilih dokumen Android.
- Untuk distribusi publik, gunakan nama, logo, dan konten yang orisinal serta pastikan hak distribusinya.
